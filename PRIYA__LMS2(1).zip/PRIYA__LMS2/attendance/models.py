from django.db import models
from main.models import Student, Course

class Attendance(models.Model):
    # Model representing attendance records

    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    # Foreign key relationship with the Student model, on_delete specifies the behavior when the related student is deleted

    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    # Foreign key relationship with the Course model, on_delete specifies the behavior when the related course is deleted

    date = models.DateField(null=False, blank=False)
    # Date field representing the date of the attendance record, cannot be null or blank

    status = models.BooleanField(default=False, blank=False, null=False)
    # Boolean field representing the attendance status, default value is False, cannot be null or blank

    cr_at = models.DateTimeField(auto_now_add=True)
    # DateTime field representing the creation timestamp, automatically set when the record is created

    upd_at = models.DateTimeField(auto_now=True)
    # DateTime field representing the last update timestamp, automatically updated whenever the record is modified

    def __str__(self):
        # String representation of the Attendance object
        return self.student.Stud_Na + ' - ' + self.course.name + ' - ' + self.date.strftime('%d-%m-%Y')

    def total_absent(self):
        # Method to calculate the total number of absences for the student
        attendance = Attendance.objects.filter(student=self.student, status=False).count()
        if attendance == 0:
            return attendance
        else:
            return attendance - 1

    def total_present(self):
        # Method to calculate the total number of presences for the student
        present = Attendance.objects.filter(student=self.student, status=True).count()
        if present == 0:
            return present
        else:
            return present - 1
