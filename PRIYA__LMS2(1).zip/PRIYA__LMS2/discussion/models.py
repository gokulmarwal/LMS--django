from django.db import models
from main.models import Student, Faculty, Course

class StudentDiscussion(models.Model):
    # Model representing student discussions

    content = models.TextField(max_length=1600, null=False)
    # Text field to store the content of the discussion, maximum length is 1600 characters, cannot be null

    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='discussions')
    # Foreign key relationship with the Course model, on_delete specifies the behavior when the related course is
    # deleted The related_name allows accessing discussions related to a course using 'course.discussions'

    sent_by = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='discussions')
    # Foreign key relationship with the Student model, on_delete specifies the behavior when the related student is
    # deleted The related_name allows accessing discussions related to a student using 'student.discussions'

    sent_at = models.DateTimeField(auto_now_add=True)
    # DateTime field representing the timestamp when the discussion was sent, automatically set when the record is
    # created

    class Meta:
        ordering = ['-sent_at']
    # Meta class to specify the default ordering for discussions based on the sent_at field

    def __str__(self):
        return self.content[:30]
    # String representation of the StudentDiscussion object, displaying the first 30 characters of the content

    def time(self):
        return self.sent_at.strftime("%d-%b-%y, %I:%M %p")
    # Method to format the sent_at timestamp as a string in the specified format

class FacultyDiscussion(models.Model):
    # Model representing faculty discussions

    content = models.TextField(max_length=1600, null=False)
    # Text field to store the content of the discussion, maximum length is 1600 characters, cannot be null

    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='courseDiscussions')
    # Foreign key relationship with the Course model, on_delete specifies the behavior when the related course is
    # deleted The related_name allows accessing discussions related to a course using 'course.courseDiscussions'

    sent_by = models.ForeignKey(Faculty, on_delete=models.CASCADE, related_name='courseDiscussions')
    # Foreign key relationship with the Faculty model, on_delete specifies the behavior when the related faculty is
    # deleted The related_name allows accessing discussions related to a faculty using 'faculty.courseDiscussions'

    sent_at = models.DateTimeField(auto_now_add=True)
    # DateTime field representing the timestamp when the discussion was sent, automatically set when the record is
    # created

    class Meta:
        ordering = ['-sent_at']
    # Metaclass to specify the default ordering for discussions based on the sent_at field

    def __str__(self):
        return self.content[:30]
    # String representation of the FacultyDiscussion object, displaying the first 30 characters of the content

    def time(self):
        return self.sent_at.strftime("%d-%b-%y, %I:%M %p")
    # Method to format the sent_at timestamp as a string in the specified format
