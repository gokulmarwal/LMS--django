
# Importing functions from Django for redirecting and rendering templates
from django.shortcuts import redirect, render

# Importing the models for faculty and student discussions
from discussion.models import FacultyDiscussion, StudentDiscussion

# Importing models from the 'main' module
from main.models import Student, Faculty, Course

# Importing authorization functions from 'main.views'
from main.views import is_faculty_authorised, is_student_authorised

# Importing the 'chain' function from itertools module
from itertools import chain

# Importing discussion form classes
from .forms import StudentDiscussionForm, FacultyDiscussionForm


def context_list(course):
    # Helper function to retrieve and sort discussions for a course
    try:
        # Retrieve student and faculty discussions for the given course
        studentDis = StudentDiscussion.objects.filter(course=course)
        facultyDis = FacultyDiscussion.objects.filter(course=course)
        # Combine student and faculty discussions into a single list
        discussions = list(chain(studentDis, facultyDis))
        # Sort the discussions based on the 'sent_at' field in descending order
        discussions.sort(key=lambda x: x.sent_at, reverse=True)

        for dis in discussions:
            if dis.__class__.__name__ == 'StudentDiscussion':
                # Set the author attribute as the student object for student discussions
                dis.author = Student.objects.get(stu_idnt=dis.sent_by_id)
            else:
                # Set the author attribute as the faculty object for faculty discussions
                dis.author = Faculty.objects.get(faculty_id=dis.sent_by_id)
    except:
        discussions = []  # Set an empty list if an exception occurs

    return discussions


def discussion(request, code):
    # View function for displaying discussions
    if is_student_authorised(request, code):
        # Check if the user is a student and authorized to access the course discussions
        course = Course.objects.get(code=code)
        student = Student.objects.get(stu_idnt=request.session['stu_idnt'])
        discussions = context_list(course)
        form = StudentDiscussionForm()
        context = {
            'course': course,
            'student': student,
            'discussions': discussions,
            'form': form,
        }
        return render(request, 'discussion/discussion.html', context)

    elif is_faculty_authorised(request, code):
        # Check if the user is a faculty and authorized to access the course discussions
        course = Course.objects.get(code=code)
        faculty = Faculty.objects.get(faculty_id=request.session['faculty_id'])
        discussions = context_list(course)
        form = FacultyDiscussionForm()
        context = {
            'course': course,
            'faculty': faculty,
            'discussions': discussions,
            'form': form,
        }
        return render(request, 'discussion/discussion.html', context)
    else:
        return redirect('std_login')


def send(request, code, std_id):
    # View function for sending student discussions
    if is_student_authorised(request, code):
        # Check if the user is a student and authorized to send discussions
        if request.method == 'POST':
            form = StudentDiscussionForm(request.POST)
            if form.is_valid():
                content = form.cleaned_data['content']
                course = Course.objects.get(code=code)
                try:
                    student = Student.objects.get(stu_idnt=std_id)
                except:
                    return redirect('discussion', code=code)
                StudentDiscussion.objects.create(
                    content=content, course=course, sent_by=student)
                return redirect('discussion', code=code)
            else:
                return redirect('discussion', code=code)
        else:
            return redirect('discussion', code=code)
    else:
        return render(request, 'std_login.html')


def send_fac(request, code, fac_id):
    # View function for sending faculty discussions
    if is_faculty_authorised(request, code):
        # Check if the user is a faculty and authorized to send discussions
        if request.method == 'POST':
            form = FacultyDiscussionForm(request.POST)
            if form.is_valid():
                content = form.cleaned_data['content']
                course = Course.objects.get(code=code)
                try:
                    faculty = Faculty.objects.get(faculty_id=fac_id)
                except:
                    return redirect('discussion', code=code)
                FacultyDiscussion.objects.create(
                    content=content, course=course, sent_by=faculty)
                return redirect('discussion', code=code)
            else:
                return redirect('discussion', code=code)
        else:
            return redirect('discussion', code=code)
    else:
        return render(request, 'std_login.html')
