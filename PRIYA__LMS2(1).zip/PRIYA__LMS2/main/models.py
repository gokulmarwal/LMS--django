# importing the model from the django
from django.db import models
# intake the FroalaField from the froala_editor.fields
from froala_editor.fields import FroalaField




class Student(models.Model):
    # Characterize the student information

    stu_idnt = models.IntegerField(primary_key=True)
    # A number field addressing the essential key of the understudy

    Stud_Na = models.CharField(max_length=100, null=False)
    # A person field addressing the name of the understudy

    stud_mail = models.EmailField(null=True, max_length=100, blank=True)
    # An email field addressing the email of the understudy
    # It permits invalid qualities (discretionary) and clear qualities (void strings)

    password = models.CharField(max_length=255, null=False)
    # A person field addressing the secret phrase of the understudy

    role = models.CharField(default="Student", max_length=100, null=False, blank=True)
    # A person field addressing the job of the understudy
    # It has a default worth of "Understudy" and permits clear qualities (void strings)

    course = models.ManyToManyField('Course', related_name='students', blank=True)
    # A many-to-numerous relationship field with the 'Course' model
    # It addresses the courses that the understudy is signed up for
    # The connected name is set as 'understudies'
    # It permits clear qualities (void determinations)

    stu_img = models.ImageField(upload_to='profile_pics', blank=True, null=False, default='profile_pics/default_student.png')
    # A picture field addressing the profile image of the understudy
    # The pictures are transferred to the 'profile_pics' index
    # It permits clear qualities (no picture chose)
    # The default picture is set as 'profile_pics/default_student.png'

    department = models.ForeignKey('Department', on_delete=models.CASCADE, null=False, blank=False, related_name='students')
    # An unfamiliar key field addressing the division of the understudy
    # It lays out a one-to-numerous relationship with the 'Division' model
    # The connected name is set as 'understudies'
    # It doesn't permit invalid or clear qualities

    def delete(self, *args, **kwargs):
        # Supersede the erase strategy to perform custom rationale while erasing an understudy

        if self.stu_img != 'profile_pics/default_student.png':
            # On the off chance that the understudy has a custom profile picture (not the default one)

            self.stu_img.delete()
            # Erase the profile picture from the capacity

        super().delete(*args, **kwargs)
        # Call the parent class erase technique to erase the understudy

    class Meta:
        verbose_name_plural = 'Students'
        # Set plural

    def __str__(self):
        #defend the self function fpr the calling
        return self.Stud_Na
        # Return the name of the understudy when it is changed over completely to a string


class Faculty(models.Model):
    # Define the Faculty model

    faculty_id = models.IntegerField(primary_key=True)
    # An integer field representing the primary key of the faculty member
    # Importing the FroalaField from the froala_editor.fields module
    fac_N = models.CharField(max_length=100, null=False)
    # A character field representing the name of the faculty member

    fac_mail = models.EmailField(max_length=100, null=True, blank=True)
    # An email field representing the email of the faculty member
    # It allows null values (optional) and blank values (empty strings)

    password = models.CharField(max_length=255, null=False)
    # A character field representing the password of the faculty member

    department = models.ForeignKey('Department', on_delete=models.CASCADE, related_name='faculty', null=False)
    # A foreign key field representing the department of the faculty member
    # It establishes a one-to-many relationship with the 'Department' model
    # The related name is set as 'faculty'
    # It does not allow null values

    role = models.CharField(default="Faculty", max_length=100, null=False, blank=True)
    # A character field representing the role of the faculty member
    # It has a default value of "Faculty" and allows blank values (empty strings)

    fac_imag = models.ImageField(upload_to='profile_pics', blank=True, null=False, default='profile_pics/default_faculty.png')
    # An image field representing the profile picture of the faculty member
    # The images are uploaded to the 'profile_pics' directory
    # It allows blank values (no image selected)
    # The default image is set as 'profile_pics/default_faculty.png'

    def delete(self, *args, **kwargs):
        # Override the delete method to perform custom logic when deleting a faculty member

        if self.fac_imag != 'profile_pics/default_faculty.png':
            # If the faculty member has a custom profile picture (not the default one)

            self.fac_imag.delete()
            # Delete the profile picture from the storage

        super().delete(*args, **kwargs)
        # Call the parent class delete method to delete the faculty member

    class Meta:
        verbose_name_plural = 'Faculty'
        # Set plural for model as 'Faculty'

    def __str__(self):
        return self.fac_N
        # Display the faculty_n of the faculty member when it is converted to a string


class Department(models.Model):
    # Define the Department model

    depart_idtnti = models.IntegerField(primary_key=True)
    # An integer field representing the primary key of the department

    dept_n = models.CharField(max_length=100, null=False)
    # A character field representing the name of the department

    description = models.TextField(null=True, blank=True)
    # A text field representing the description of the department
    # It allows null values (optional) and blank values (empty strings)

    class Meta:
        verbose_name_plural = 'Departments'
        # Set plural for the model as 'Departments'

    def __str__(self):
        return self.dept_n
        # Return the name of the department when it is converted to a string

    def student_count(self):
        return self.students.count()
        # Return the count of students associated with the department

    def faculty_count(self):
        return self.faculty.count()
        # Return the count of faculty members associated with the department

    def course_count(self):
        return self.courses.count()
        # Return the count of courses associated with the department


class Course(models.Model):
    # Define the Course model

    code = models.IntegerField(primary_key=True)
    # An integer field representing the primary key of the course

    name = models.CharField(null=False, unique=True, max_length=255)
    # A character field representing the name of the course
    # It does not allow null values and enforces uniqueness

    department = models.ForeignKey(Department, related_name='courses', null=False, on_delete=models.CASCADE)
    # A foreign key field representing the department of the course
    # It establishes a one-to-many relationship with the 'Department' model
    # The related name is set as 'courses'
    # It does not allow null values

    faculty = models.ForeignKey(Faculty, blank=True, null=True, on_delete=models.SET_NULL)
    # A foreign key field representing the faculty member associated with the course
    # It establishes a one-to-many relationship with the 'Faculty' model
    # The faculty member can be set as null (optional)
    # If the faculty member is deleted, the course's faculty field will be set to null

    studentKey = models.IntegerField(null=False, unique=True)
    # An integer field representing the unique key for the course used by students

    facultyKey = models.IntegerField(null=False, unique=True)
    # An integer field representing the unique key for the course used by faculty members

    class Meta:
        unique_together = ('code', 'department', 'name')
        # Define a unique constraint on the combination of code, department, and name fields
        # Ensures that each course has a unique combination of code, department, and name

        verbose_name_plural = "Courses"
        # Set plural for the model as 'Courses'

    def __str__(self):
        return self.name
        # Return the name of the course when it is converted to a string

class Announcement(models.Model):
    # Define the Announcement model

    course_code = models.ForeignKey(Course, null=False, on_delete=models.CASCADE)
    # A foreign key field representing the course associated with the announcement
    # It establishes a one-to-many relationship with the 'Course' model
    # It does not allow null values

    datetime = models.DateTimeField(null=False, auto_now_add=True)
    # A datetime field representing the date and time when the announcement is created
    # It does not allow null values

    description = FroalaField()
    # A custom FroalaField representing the description of the announcement
    # It allows rich text formatting

    class Meta:
        verbose_name_plural = "Announcements"
        # Set plural for model as 'Announcements'

        ordering = ['-datetime']
        # Set the default ordering of the announcements based on the datetime field in descending order

    def __str__(self):
        return self.datetime.strftime("%d-%b-%y, %I:%M %p")
        # Return the formatted datetime string when the announcement is converted to a string

    def post_date(self):
        return self.datetime.strftime("%d-%b-%y, %I:%M %p")
        # Return the formatted datetime string representing the post date of the announcement


class Assignment(models.Model):
    # Define the Assignment model

    course_code = models.ForeignKey(Course, null=False, on_delete=models.CASCADE)
    # A foreign key field representing the course associated with the assignment
    # It establishes a one-to-many relationship with the 'Course' model
    # It does not allow null values

    cou_tit = models.CharField(max_length=255, null=False)
    # A character field representing the title of the assignment
    # It does not allow null values

    description = models.TextField(null=False)
    # A text field representing the description of the assignment
    # It does not allow null values

    datetime = models.DateTimeField(null=False,auto_now_add=True)
    # A datetime field representing the date and time when the assignment is created
    # It does not allow null values

    deadline = models.DateTimeField(null=False)
    # A datetime field representing the deadline for the assignment
    # It does not allow null values

    file = models.FileField(upload_to='assignments/', null=True, blank=True)
    # A file field representing any additional files related to the assignment
    # The files are uploaded to the 'assignments/' directory
    # It allows null values (optional) and blank values (no file selected)

    marks = models.DecimalField(null=False,max_digits=6, decimal_places=2)
    # A decimal field representing the maximum marks for the assignment
    # It does not allow null values

    class Meta:
        verbose_name_plural = "Assignments"
        # Set plural model as 'Assignments'

        ordering = ['-datetime']
        # Set the default ordering of the assignments based on the datetime field in descending order

    def __str__(self):
        return self.cou_tit
        # Return the title of the assignment when it is converted to a string

    def deleted(self, *args, **kwargs):
        # Override the delete method to delete
        self.file.delete()
        # the associated file when deleting the assignment
        super().delete(*args, **kwargs)


    def post_date(self):
        return self.datetime.strftime("%d-%b-%y, %I:%M %p")
        # Display  the formatted datetime string representing the post date of the assignment

    def due_date(self):
        return self.deadline.strftime("%d-%b-%y, %I:%M %p")
        # Display the formatted datetime string representing the due date of the assignment


class Submission(models.Model):
    # Define the Submission

    assi = models.ForeignKey(Assignment, null=False, on_delete=models.CASCADE)
    # A foreign key field representing the assignment associated with the submission
    # It establishes a one-to-many relationship with the 'Assignment' model
    # It does not allow null values

    student = models.ForeignKey(Student,  null=False, on_delete=models.CASCADE)
    # A foreign key field representing the student who submitted the assignment
    # It establishes a one-to-many relationship with the 'Student' model
    # It does not allow null values

    file = models.FileField(upload_to='submissions/', null=True)
    # A file field representing the submitted file
    # The files are uploaded to the 'submissions/' directory
    # It allows null values (optional)

    datetime = models.DateTimeField(null=False, auto_now_add=True)
    # A datetime field representing the date and time when the submission is created
    # It is automatically set to the current date and time when the object is created
    # It does not allow null values

    marks = models.DecimalField(max_digits=6, blank=True, null=True, decimal_places=2)
    # A decimal field representing the marks obtained for the submission
    # It allows null values (optional) and blank values

    sttus = models.CharField(blank=True, max_length=100, null=True )
    # A character field representing the status of the submission
    # It allows null values (optional) and blank values

    def file_name(self):
        return self.file.name.split('/')[-1]
        # Return of the submitted file

    def time_difference(self):
        # Calculate the time difference between the assignment deadline and the submission datetime

        difference = self.assi.deadline - self.datetime
        d = difference.days
        h = difference.seconds // 3600
        m = (difference.seconds // 60) % 60
        s = difference.seconds % 60

        if d == 0:
            if h == 0:
                if m == 0:
                    return str(s) + " s"
                else:
                    return str(m) + " m " + str(s) + " s"
            else:
                return str(h) + " h " + str(m) + " m " + str(s) + " s"
        else:
            return str(d) + " d " + str(h) + " h " + str(m) + " m " + str(s) + " s"

    def submission_date(self):
        return self.datetime.strftime("%d-%b-%y, %I:%M %p")
        # Display the formatted datetime string representing the submission date

    def deleted(self, *args, **kwargs):
        # Override the delete method
        self.file.delete()
        # to delete the associated file
        super().delete(*args, **kwargs)
        # when deleting the submission

    def __str__(self):
        # initializing the self function
        return self.student.Stud_Na + " - " + self.assi.cou_tit
        # Return a string representation of the submission


class Material(models.Model):
    # Define the Material model

    course_code = models.ForeignKey(Course, null=False, on_delete=models.CASCADE)
    # A foreign key field representing the course associated with the material
    # It establishes a one-to-many relationship with the 'Course' model
    # It does not allow null values

    description = models.TextField(max_length=2000, null=False)
    # A text field representing the description of the material
    # It does not allow null values

    datetime = models.DateTimeField(null=False, auto_now_add=True)
    # A datetime field representing the date and time when the material is created
    # It does not allow null values

    file = models.FileField(upload_to='materials/', null=True, blank=True)
    # A file field representing the material file
    # The files are uploaded to the 'materials/' directory
    # It allows null values (optional) and blank values (no file selected)

    class Meta:
        verbose_name_plural = "Materials"
        # Set plural for model as 'Materials'

        ordering = ['-datetime']
        # Set the default ordering of the materials based on the datetime field in descending order

    def __str__(self):
        # converted to a string
        return self.title
        # Return the title of the material

    def deleted(self, *args, **kwargs):
        # Override the delete method to delete
        self.file.delete()
        #the associated file when deleting the material
        super().delete(*args, **kwargs)


    def post_date(self):
        return self.datetime.strftime("%d-%b-%y, %I:%M %p")
        # display the formatted datetime string representing the post date of the material
