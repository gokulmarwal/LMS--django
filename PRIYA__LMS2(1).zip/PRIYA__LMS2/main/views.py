import datetime
# Importing the datetime module

from django.shortcuts import redirect, render
# Importing functions from Django for rendering templates and redirecting
from django.contrib import messages
# Importing the messages module from Django for displaying messages
from .models import Student, Course, Announcement, Assignment, Submission, Material, Faculty, Department
# Importing models from the current Django app
from django.template.defaulttags import register
# Importing the register module from Django for template tags
from django.db.models import Count, Q
# Importing functions for querying the database
from django.http import HttpResponseRedirect
# Importing the HttpResponseRedirect class from Django for redirecting
from .forms import AnnouncementForm, AssignmentForm, MaterialForm
# Importing forms from the current Django app

from django.core import validators
# Importing validators from Django forms

# Importing forms module from Django (duplicate import statement, can be removed)
from django import forms

class LoginForm(forms.Form):
    # Define a login form class using Django's forms.Form
    # It has two fields: 'id' and 'password'
    id = forms.CharField(label='ID', max_length=10, validators=[
        validators.RegexValidator(r'^\d+$', 'Please enter a valid number.')])
    password = forms.CharField(widget=forms.PasswordInput)


def is_student_authorised(request, code):
    # Checks if a student is authorized to access a course
    course = Course.objects.get(code=code)
    if request.session.get('stu_idnt') and course in Student.objects.get(stu_idnt=request.session['stu_idnt']).course.all():
        return True
    else:
        return False


def is_faculty_authorised(request, code):
    # Checks if a faculty is authorized to access a course
    if request.session.get('faculty_id') and code in Course.objects.filter(faculty_id=request.session['faculty_id']).values_list('code', flat=True):
        return True
    else:
        return False


def std_login(request):
    # Custom login page for both students and faculty
    error_messages = []

    if request.method == 'POST':
        # Handle form submission if the request method is POST
        form = LoginForm(request.POST)

        if form.is_valid():
            # Validate the form data
            id = form.cleaned_data['id']
            password = form.cleaned_data['password']

            if Student.objects.filter(stu_idnt=id, password=password).exists():
                # Check if the login credentials belong to a student
                request.session['stu_idnt'] = id
                return redirect('myCourses')
            elif Faculty.objects.filter(faculty_id=id, password=password).exists():
                # Check if the login credentials belong to a faculty
                request.session['faculty_id'] = id
                return redirect('facultyCourses')
            else:
                error_messages.append('Invalid login credentials.')
        else:
            error_messages.append('Invalid form data.')
    else:
        # Create a new instance of the login form if the request method is not POST
        form = LoginForm()

    if 'stu_idnt' in request.session:
        # If a student is already logged in, redirect to the student's course page
        return redirect('/my/')
    elif 'faculty_id' in request.session:
        # If a faculty is already logged in, redirect to the faculty's course page
        return redirect('/facultyCourses/')

    context = {'form': form, 'error_messages': error_messages}
    # Render the login page with the form and error messages (if any)
    return render(request, 'login_page.html', context)


def std_logout(request):
    # Clears the session on logout
    request.session.flush()
    return redirect('std_login')


def myCourses(request):
    # Display all courses from a student's perspective
    try:
        if request.session.get('stu_idnt'):
            # Check if a student is logged in
            student = Student.objects.get(stu_idnt=request.session['stu_idnt'])
            courses = student.course.all()
            faculty = student.course.all().values_list('faculty_id', flat=True)

            context = {
                'courses': courses,
                'student': student,
                'faculty': faculty
            }
            # Render the student's course page with the course details
            return render(request, 'main/myCourses.html', context)
        else:
            # If no student is logged in, redirect to the login page
            return redirect('std_login')
    except:
        # Handle any exceptions and render an error page
        return render(request, 'error.html')

# Display all courses (faculty view)
def facultyCourses(request):
    try:
        # Checking if the 'faculty_id' key exists in the session
        if request.session['faculty_id']:
            # Retrieving the Faculty object with the matching faculty_id from the session
            faculty = Faculty.objects.get(faculty_id=request.session['faculty_id'])

            # Retrieving the Course objects associated with the faculty_id
            courses = Course.objects.filter(faculty_id=request.session['faculty_id'])

            # Calculating the student count for each course
            studentCount = Course.objects.all().annotate(student_count=Count('students'))

            studentCountDict = {}

            # Populating a dictionary with course codes as keys and student counts as values
            for course in studentCount:
                studentCountDict[course.code] = course.student_count

            # Registering a custom filter named 'get_item' to access dictionary values in the template
            @register.filter
            def get_item(dictionary, course_code):
                return dictionary.get(course_code)

            # Creating a context dictionary with relevant data
            context = {
                'courses': courses,
                'faculty': faculty,
                'studentCount': studentCountDict
            }

            # Rendering the 'facultyCourses.html' template with the provided context
            return render(request, 'main/facultyCourses.html', context)
        else:
            # Redirecting to the 'std_login' view if 'faculty_id' is not present in the session
            return redirect('std_login')
    except:
        # Redirecting to the 'std_login' view if an exception occurs
        return redirect('std_login')


# Particular course page (student view)
def course_page(request, code):
    try:
        # Retrieving the Course object with the matching code
        course = Course.objects.get(code=code)

        # Checking if the student is authorized to access the course
        if is_student_authorised(request, code):
            try:
                # Retrieving the announcements, assignments, and materials associated with the course
                announcements = Announcement.objects.filter(course_code=course)
                assignments = Assignment.objects.filter(course_code=course.code)
                materials = Material.objects.filter(course_code=course.code)
            except:
                # Handling exceptions by setting the respective variables to None
                announcements = None
                assignments = None
                materials = None

            # Creating a context dictionary with relevant data
            context = {
                'course': course,
                'announcements': announcements,
                'assignments': assignments[:3],
                'materials': materials,
                'student': Student.objects.get(stu_idnt=request.session['stu_idnt'])
            }

            # Rendering the 'course.html' template with the provided context
            return render(request, 'main/course.html', context)
        else:
            # Redirecting to the 'std_login' view if the student is not authorized
            return redirect('std_login')
    except:
        # Rendering the 'error.html' template if an exception occurs
        return render(request, 'error.html')


# Particular course page (faculty view)
def course_page_faculty(request, code):
    # Retrieving the Course object with the matching code
    course = Course.objects.get(code=code)

    # Checking if the 'faculty_id' key exists in the session
    if request.session.get('faculty_id'):
        try:
            # Retrieving the announcements, assignments, and materials associated with the course
            announcements = Announcement.objects.filter(course_code=course)
            assignments = Assignment.objects.filter(course_code=course.code)
            materials = Material.objects.filter(course_code=course.code)

            # Counting the number of students enrolled in the course
            studentCount = Student.objects.filter(course=course).count()
        except:
            # Handling exceptions by setting the respective variables to None
            announcements = None
            assignments = None
            materials = None

        # Creating a context dictionary with relevant data
        context = {
            'course': course,
            'announcements': announcements,
            'assignments': assignments[:3],
            'materials': materials,
            'faculty': Faculty.objects.get(faculty_id=request.session['faculty_id']),
            'studentCount': studentCount
        }

        # Rendering the 'faculty_course.html' template with the provided context
        return render(request, 'main/faculty_course.html', context)
    else:
        # Redirecting to the 'std_login' view if the 'faculty_id' key is not present in the session
        return redirect('std_login')


def error(request):
    # Rendering the 'error.html' template
    return render(request, 'error.html')


def profile(request, id):
    try:
        if request.session['stu_idnt'] == id:
            # Retrieving the Student object with the matching id
            student = Student.objects.get(stu_idnt=id)

            # Rendering the 'profile.html' template with the student object in the context
            return render(request, 'main/profile.html', {'student': student})
        else:
            # Redirecting to the 'std_login' view if the 'stu_idnt' key in the session does not match the provided id
            return redirect('std_login')
    except:
        try:
            if request.session['faculty_id'] == id:
                # Retrieving the Faculty object with the matching id
                faculty = Faculty.objects.get(faculty_id=id)

                # Rendering the 'faculty_profile.html' template with the faculty object in the context
                return render(request, 'main/faculty_profile.html', {'faculty': faculty})
            else:
                # Redirecting to the 'std_login' view if the 'faculty_id' key in the session does not match the provided id
                return redirect('std_login')
        except:
            # Rendering the 'error.html' template if an exception occurs
            return render(request, 'error.html')


def addAnnouncement(request, code):
    # Checking if the faculty is authorized to add an announcement for the course
    if is_faculty_authorised(request, code):
        if request.method == 'POST':
            # Creating an instance of the AnnouncementForm with the submitted data
            form = AnnouncementForm(request.POST)
            # Assigning the course_code field of the form to the Course object with the matching code
            form.instance.course_code = Course.objects.get(code=code)

            if form.is_valid():
                # Saving the form data as a new Announcement object
                form.save()
                # Displaying a success message
                messages.success(request, 'Announcement added successfully.')
                return redirect('/faculty/' + str(code))
        else:
            # Creating a new instance of the AnnouncementForm
            form = AnnouncementForm()

        # Creating a context dictionary with relevant data
        context = {
            'course': Course.objects.get(code=code),
            'faculty': Faculty.objects.get(faculty_id=request.session['faculty_id']),
            'form': form
        }

        # Rendering the 'announcement.html' template with the provided context
        return render(request, 'main/announcement.html', context)
    else:
        # Redirecting to the 'std_login' view if the faculty is not authorized
        return redirect('std_login')


def deleteAnnouncement(request, code, id):
    # Checking if the faculty is authorized to delete the announcement for the course
    if is_faculty_authorised(request, code):
        try:
            # Retrieving the Announcement object with the matching course_code and id
            announcement = Announcement.objects.get(course_code=code, id=id)
            # Deleting the announcement
            announcement.deleted()
            # Displaying a warning message
            messages.warning(request, 'Announcement deleted successfully.')
            return redirect('/faculty/' + str(code))
        except:
            return redirect('/faculty/' + str(code))
    else:
        return redirect('std_login')


def editAnnouncement(request, code, id):
    # Checking if the faculty is authorized to edit the announcement for the course
    if is_faculty_authorised(request, code):
        # Retrieving the Announcement object with the matching course_code_id and id
        announcement = Announcement.objects.get(course_code_id=code, id=id)
        # Creating a form instance with the announcement as the initial data
        form = AnnouncementForm(instance=announcement)

        # Creating a context dictionary with relevant data
        context = {
            'announcement': announcement,
            'course': Course.objects.get(code=code),
            'faculty': Faculty.objects.get(faculty_id=request.session['faculty_id']),
            'form': form
        }

        # Rendering the 'update-announcement.html' template with the provided context
        return render(request, 'main/update-announcement.html', context)
    else:
        # Redirecting to the 'std_login' view if the faculty is not authorized
        return redirect('std_login')


def updateAnnouncement(request, code, id):
    # Checking if the faculty is authorized to update the announcement for the course
    if is_faculty_authorised(request, code):
        try:
            # Retrieving the Announcement object with the matching course_code_id and id
            announcement = Announcement.objects.get(course_code_id=code, id=id)
            # Creating a form instance with the request POST data and the announcement as the initial data
            form = AnnouncementForm(request.POST, instance=announcement)

            if form.is_valid():
                # Saving the updated form data to the Announcement object
                form.save()
                # Displaying an info message
                messages.info(request, 'Announcement updated successfully.')
                return redirect('/faculty/' + str(code))
        except:
            return redirect('/faculty/' + str(code))
    else:
        return redirect('std_login')


def addAssignment(request, code):
    # Checking if the faculty is authorized to add an assignment for the course
    if is_faculty_authorised(request, code):
        if request.method == 'POST':
            # Creating an instance of the AssignmentForm with the submitted data
            form = AssignmentForm(request.POST, request.FILES)
            # Assigning the course_code field of the form to the Course object with the matching code
            form.instance.course_code = Course.objects.get(code=code)

            if form.is_valid():
                # Saving the form data as a new Assignment object
                form.save()
                # Displaying a success message
                messages.success(request, 'Assignment added successfully.')
                return redirect('/faculty/' + str(code))
        else:
            # Creating a new instance of the AssignmentForm
            form = AssignmentForm()

        # Creating a context dictionary with relevant data
        context = {
            'course': Course.objects.get(code=code),
            'faculty': Faculty.objects.get(faculty_id=request.session['faculty_id']),
            'form': form
        }

        # Rendering the 'assignment.html' template with the provided context
        return render(request, 'main/assignment.html', context)
    else:
        # Redirecting to the 'std_login' view if the faculty is not authorized
        return redirect('std_login')


def assignmentPage(request, code, id):
    # Retrieving the Course object with the matching code
    course = Course.objects.get(code=code)

    # Checking if the student is authorized to access the assignment
    if is_student_authorised(request, code):
        # Retrieving the Assignment object with the matching course_code and id
        assignment = Assignment.objects.get(course_code=course.code, id=id)

        try:
            # Retrieving the Submission object for the assignment and student
            submission = Submission.objects.get(assignment=assignment,
                                                student=Student.objects.get(stu_idnt=request.session['stu_idnt']))

            # Creating a context dictionary with relevant data
            context = {
                'assignment': assignment,
                'course': course,
                'submission': submission,
                'time': datetime.datetime.now(),
                'student': Student.objects.get(stu_idnt=request.session['stu_idnt']),
                'courses': Student.objects.get(stu_idnt=request.session['stu_idnt']).course.all()
            }

            # Rendering the 'assignment-portal.html' template with the provided context
            return render(request, 'main/assignment-portal.html', context)
        except:
            # Setting submission to None if no submission exists
            submission = None

        # Creating a context dictionary with relevant data
        context = {
            'assignment': assignment,
            'course': course,
            'submission': submission,
            'time': datetime.datetime.now(),
            'student': Student.objects.get(stu_idnt=request.session['stu_idnt']),
            'courses': Student.objects.get(stu_idnt=request.session['stu_idnt']).course.all()
        }

        # Rendering the 'assignment-portal.html' template with the provided context
        return render(request, 'main/assignment-portal.html', context)
    else:
        # Redirecting to the 'std_login' view if the student is not authorized
        return redirect('std_login')


def allAssignments(request, code):
    # Checking if the faculty is authorized to view all assignments for the course
    if is_faculty_authorised(request, code):
        # Retrieving the Course object with the matching code
        course = Course.objects.get(code=code)
        # Retrieving all assignments associated with the course
        assignments = Assignment.objects.filter(course_code=course)
        # Counting the number of students enrolled in the course
        studentCount = Student.objects.filter(course=course).count()

        # Creating a context dictionary with relevant data
        context = {
            'assignments': assignments,
            'course': course,
            'faculty': Faculty.objects.get(faculty_id=request.session['faculty_id']),
            'studentCount': studentCount
        }

        # Rendering the 'all-assignments.html' template with the provided context
        return render(request, 'main/all-assignments.html', context)
    else:
        # Redirecting to the 'std_login' view if the faculty is not authorized
        return redirect('std_login')


def allAssignmentsSTD(request, code):
    # Checking if the student is authorized to view all assignments for the course
    if is_student_authorised(request, code):
        # Retrieving the Course object with the matching code
        course = Course.objects.get(code=code)
        # Retrieving all assignments associated with the course
        assignments = Assignment.objects.filter(course_code=course)

        # Creating a context dictionary with relevant data
        context = {
            'assignments': assignments,
            'course': course,
            'student': Student.objects.get(stu_idnt=request.session['stu_idnt']),
        }

        # Rendering the 'all-assignments-std.html' template with the provided context
        return render(request, 'main/all-assignments-std.html', context)
    else:
        # Redirecting to the 'std_login' view if the student is not authorized
        return redirect('std_login')


def addSubmission(request, code, id):
    try:
        # Retrieving the Course object with the matching code
        course = Course.objects.get(code=code)

        # Checking if the student is authorized to add a submission for the assignment
        if is_student_authorised(request, code):
            # Retrieving the Assignment object with the matching course_code and id
            assignment = Assignment.objects.get(course_code=course.code, id=id)

            # Checking if the assignment deadline has passed
            if assignment.deadline < datetime.datetime.now():
                return redirect('/assignment/' + str(code) + '/' + str(id))

            if request.method == 'POST' and request.FILES['file']:
                # Retrieving the Assignment object again
                assignment = Assignment.objects.get(course_code=course.code, id=id)

                # Creating a new Submission object with the assignment, student, and file
                submission = Submission(
                    assignment=assignment,
                    student=Student.objects.get(stu_idnt=request.session['stu_idnt']),
                    file=request.FILES['file']
                )
                submission.sttus = 'Submitted'
                submission.save()

                return HttpResponseRedirect(request.path_info)
            else:
                # Retrieving the Assignment and Submission objects
                assignment = Assignment.objects.get(course_code=course.code, id=id)
                submission = Submission.objects.get(
                    assignment=assignment,
                    student=Student.objects.get(stu_idnt=request.session['stu_idnt'])
                )

                # Creating a context dictionary with relevant data
                context = {
                    'assignment': assignment,
                    'course': course,
                    'submission': submission,
                    'time': datetime.datetime.now(),
                    'student': Student.objects.get(stu_idnt=request.session['stu_idnt']),
                    'courses': Student.objects.get(stu_idnt=request.session['stu_idnt']).course.all()
                }

                # Rendering the 'assignment-portal.html' template with the provided context
                return render(request, 'main/assignment-portal.html', context)
        else:
            return redirect('std_login')
    except:
        return HttpResponseRedirect(request.path_info)


def viewSubmission(request, code, id):
    # Retrieving the Course object with the matching code
    course = Course.objects.get(code=code)

    # Checking if the faculty is authorized to view the submissions for the assignment
    if is_faculty_authorised(request, code):
        try:
            # Retrieving the Assignment object with the matching course_code_id and id
            assignment = Assignment.objects.get(course_code_id=code, id=id)

            # Retrieving all submissions for the assignment
            submissions = Submission.objects.filter(assignment_id=assignment.id)

            # Creating a context dictionary with relevant data
            context = {
                'course': course,
                'submissions': submissions,
                'assignment': assignment,
                'totalStudents': len(Student.objects.filter(course=course)),
                'faculty': Faculty.objects.get(faculty_id=request.session['faculty_id']),
                'courses': Course.objects.filter(faculty_id=request.session['faculty_id'])
            }

            # Rendering the 'assignment-view.html' template with the provided context
            return render(request, 'main/assignment-view.html', context)
        except:
            return redirect('/faculty/' + str(code))
    else:
        return redirect('std_login')


def gradeSubmission(request, code, id, sub_id):
    try:
        # Retrieving the Course object with the matching code
        course = Course.objects.get(code=code)

        # Checking if the faculty is authorized to grade the submission
        if is_faculty_authorised(request, code):
            if request.method == 'POST':
                # Retrieving the Assignment and Submission objects
                assignment = Assignment.objects.get(course_code_id=code, id=id)
                submissions = Submission.objects.filter(assignment_id=assignment.id)
                submission = Submission.objects.get(assignment_id=id, id=sub_id)

                # Updating the marks of the submission
                submission.marks = request.POST['marks']
                if request.POST['marks'] == 0:
                    submission.marks = 0
                submission.save()

                return HttpResponseRedirect(request.path_info)
            else:
                # Retrieving the Assignment and Submission objects
                assignment = Assignment.objects.get(course_code_id=code, id=id)
                submissions = Submission.objects.filter(assignment_id=assignment.id)
                submission = Submission.objects.get(assignment_id=id, id=sub_id)

                # Creating a context dictionary with relevant data
                context = {
                    'course': course,
                    'submissions': submissions,
                    'assignment': assignment,
                    'totalStudents': len(Student.objects.filter(course=course)),
                    'faculty': Faculty.objects.get(faculty_id=request.session['faculty_id']),
                    'courses': Course.objects.filter(faculty_id=request.session['faculty_id'])
                }

                # Rendering the 'assignment-view.html' template with the provided context
                return render(request, 'main/assignment-view.html', context)
        else:
            return redirect('std_login')
    except:
        return redirect('/error/')


def addCourseMaterial(request, code):
    # Checking if the faculty is authorized to add a course material for the course
    if is_faculty_authorised(request, code):
        if request.method == 'POST':
            # Creating an instance of the MaterialForm with the submitted data
            form = MaterialForm(request.POST, request.FILES)
            # Assigning the course_code field of the form to the Course object with the matching code
            form.instance.course_code = Course.objects.get(code=code)

            if form.is_valid():
                # Saving the form data as a new Material object
                form.save()
                # Displaying a success message
                messages.success(request, 'New course material added')
                return redirect('/faculty/' + str(code))
            else:
                return render(request, 'main/course-material.html', {'course': Course.objects.get(code=code),
                                                                     'faculty': Faculty.objects.get(
                                                                         faculty_id=request.session['faculty_id']),
                                                                     'form': form})
        else:
            # Creating a new instance of the MaterialForm
            form = MaterialForm()
            return render(request, 'main/course-material.html', {'course': Course.objects.get(code=code),
                                                                 'faculty': Faculty.objects.get(
                                                                     faculty_id=request.session['faculty_id']),
                                                                 'form': form})
    else:
        return redirect('std_login')


def deleteCourseMaterial(request, code, id):
    # Checking if the faculty is authorized to delete the course material
    if is_faculty_authorised(request, code):
        # Retrieving the Course and Material objects
        course = Course.objects.get(code=code)
        course_material = Material.objects.get(course_code=course, id=id)
        # Marking the course material as deleted
        course_material.deleted()
        # Displaying a warning message
        messages.warning(request, 'Course material deleted')
        return redirect('/faculty/' + str(code))
    else:
        return redirect('std_login')


def courses(request):
    # Checking if the user (student or faculty) is authenticated
    if request.session.get('stu_idnt') or request.session.get('faculty_id'):
        # Retrieving all courses
        courses = Course.objects.all()

        if request.session.get('stu_idnt'):
            # Retrieving the student object
            student = Student.objects.get(stu_idnt=request.session['stu_idnt'])
        else:
            student = None

        if request.session.get('faculty_id'):
            # Retrieving the faculty object
            faculty = Faculty.objects.get(faculty_id=request.session['faculty_id'])
        else:
            faculty = None

        # Retrieving the enrolled courses for the student or accessed courses for the faculty
        enrolled = student.course.all() if student else None
        accessed = Course.objects.filter(faculty_id=faculty.faculty_id) if faculty else None

        # Creating a context dictionary with relevant data
        context = {
            'faculty': faculty,
            'courses': courses,
            'student': student,
            'enrolled': enrolled,
            'accessed': accessed
        }

        # Rendering the 'all-courses.html' template with the provided context
        return render(request, 'main/all-courses.html', context)
    else:
        return redirect('std_login')


def departments(request):
    # Checking if the user (student or faculty) is authenticated
    if request.session.get('stu_idnt') or request.session.get('faculty_id'):
        # Retrieving all departments
        departments = Department.objects.all()

        if request.session.get('stu_idnt'):
            # Retrieving the student object
            student = Student.objects.get(stu_idnt=request.session['stu_idnt'])
        else:
            student = None

        if request.session.get('faculty_id'):
            # Retrieving the faculty object
            faculty = Faculty.objects.get(faculty_id=request.session['faculty_id'])
        else:
            faculty = None

        # Creating a context dictionary with relevant data
        context = {
            'faculty': faculty,
            'student': student,
            'deps': departments
        }

        # Rendering the 'departments.html' template with the provided context
        return render(request, 'main/departments.html', context)
    else:
        return redirect('std_login')


def access(request, code):
    # Checking if the user is a student
    if request.session.get('stu_idnt'):
        # Retrieving the Course and Student objects
        course = Course.objects.get(code=code)
        student = Student.objects.get(stu_idnt=request.session['stu_idnt'])

        if request.method == 'POST':
            # Checking if the entered key matches the course studentKey
            if request.POST['key'] == str(course.studentKey):
                # Enrolling the student in the course
                student.course.add(course)
                student.save()
                return redirect('/my/')
            else:
                # Displaying an error message for invalid key
                messages.error(request, 'Invalid key')
                return HttpResponseRedirect(request.path_info)
        else:
            # Rendering the 'access.html' template with the provided context
            return render(request, 'main/access.html', {'course': course, 'student': student})
    else:
        return redirect('std_login')


def search(request):
    # Checking if the user (student or faculty) is authenticated
    if request.session.get('stu_idnt') or request.session.get('faculty_id'):
        if request.method == 'GET' and request.GET['q']:
            # Retrieving the search query
            q = request.GET['q']
            # Searching for courses based on the query
            courses = Course.objects.filter(
                Q(code__icontains=q) | Q(name__icontains=q) | Q(faculty__name__icontains=q))

            if request.session.get('stu_idnt'):
                # Retrieving the student object
                student = Student.objects.get(stu_idnt=request.session['stu_idnt'])
            else:
                student = None

            if request.session.get('faculty_id'):
                # Retrieving the faculty object
                faculty = Faculty.objects.get(faculty_id=request.session['faculty_id'])
            else:
                faculty = None

            # Retrieving the enrolled courses for the student or accessed courses for the faculty
            enrolled = student.course.all() if student else None
            accessed = Course.objects.filter(faculty_id=faculty.faculty_id) if faculty else None

            # Creating a context dictionary with relevant data
            context = {
                'courses': courses,
                'faculty': faculty,
                'student': student,
                'enrolled': enrolled,
                'accessed': accessed,
                'q': q
            }

            # Rendering the 'search.html' template with the provided context
            return render(request, 'main/search.html', context)
        else:
            return HttpResponseRedirect(request.META.get('HTTP_REFERER'))
    else:
        return redirect('std_login')

def changePasswordPrompt(request):
    # Checking if the user is a student
    if request.session.get('stu_idnt'):
        # Retrieving the student object
        student = Student.objects.get(stu_idnt=request.session['stu_idnt'])
        # Rendering the 'changePassword.html' template with the provided context
        return render(request, 'main/changePassword.html', {'student': student})
    # Checking if the user is a faculty
    elif request.session.get('faculty_id'):
        # Retrieving the faculty object
        faculty = Faculty.objects.get(faculty_id=request.session['faculty_id'])
        # Rendering the 'changePasswordFaculty.html' template with the provided context
        return render(request, 'main/changePasswordFaculty.html', {'faculty': faculty})
    else:
        return redirect('std_login')


def changePhotoPrompt(request):
    # Checking if the user is a student
    if request.session.get('stu_idnt'):
        # Retrieving the student object
        student = Student.objects.get(stu_idnt=request.session['stu_idnt'])
        # Rendering the 'changePhoto.html' template with the provided context
        return render(request, 'main/changePhoto.html', {'student': student})
    # Checking if the user is a faculty
    elif request.session.get('faculty_id'):
        # Retrieving the faculty object
        faculty = Faculty.objects.get(faculty_id=request.session['faculty_id'])
        # Rendering the 'changePhotoFaculty.html' template with the provided context
        return render(request, 'main/changePhotoFaculty.html', {'faculty': faculty})
    else:
        return redirect('std_login')


def changePassword(request):
    # Checking if the user is a student
    if request.session.get('stu_idnt'):
        # Retrieving the student object
        student = Student.objects.get(stu_idnt=request.session['stu_idnt'])
        if request.method == 'POST':
            if student.password == request.POST['oldPassword']:
                # Changing the password
                student.password = request.POST['newPassword']
                student.save()
                messages.success(request, 'Password was changed successfully')
                return redirect('/profile/' + str(student.stu_idnt))
            else:
                messages.error(request, 'Password is incorrect. Please try again')
                return redirect('/changePassword/')
        else:
            return render(request, 'main/changePassword.html', {'student': student})
    else:
        return redirect('std_login')


def changePasswordFaculty(request):
    # Checking if the user is a faculty
    if request.session.get('faculty_id'):
        # Retrieving the faculty object
        faculty = Faculty.objects.get(faculty_id=request.session['faculty_id'])
        if request.method == 'POST':
            if faculty.password == request.POST['oldPassword']:
                # Changing the password
                faculty.password = request.POST['newPassword']
                faculty.save()
                messages.success(request, 'Password was changed successfully')
                return redirect('/facultyProfile/' + str(faculty.faculty_id))
            else:
                messages.error(request, 'Password is incorrect. Please try again')
                return redirect('/changePasswordFaculty/')
        else:
            return render(request, 'main/changePasswordFaculty.html', {'faculty': faculty})
    else:
        return redirect('std_login')


def changePhoto(request):
    # Checking if the user is a student
    if request.session.get('stu_idnt'):
        # Retrieving the student object
        student = Student.objects.get(stu_idnt=request.session['stu_idnt'])
        if request.method == 'POST':
            if request.FILES['photo']:
                # Changing the photo
                student.stu_img = request.FILES['photo']
                student.save()
                messages.success(request, 'Photo was changed successfully')
                return redirect('/profile/' + str(student.stu_idnt))
            else:
                messages.error(request, 'Please select a photo')
                return redirect('/changePhoto/')
        else:
            return render(request, 'main/changePhoto.html', {'student': student})
    else:
        return redirect('std_login')


def changePhotoFaculty(request):
    # Checking if the user is a faculty
    if request.session.get('faculty_id'):
        # Retrieving the faculty object
        faculty = Faculty.objects.get(faculty_id=request.session['faculty_id'])
        if request.method == 'POST':
            if request.FILES['photo']:
                # Changing the photo
                faculty.stu_img = request.FILES['photo']
                faculty.save()
                messages.success(request, 'Photo was changed successfully')
                return redirect('/facultyProfile/' + str(faculty.faculty_id))
            else:
                messages.error(request, 'Please select a photo')
                return redirect('/changePhotoFaculty/')
        else:
            return render(request, 'main/changePhotoFaculty.html', {'faculty': faculty})
    else:
        return redirect('std_login')


def guestStudent(request):
    # Clearing the session data
    request.session.flush()
    try:
        # Retrieving the guest student object
        student = Student.objects.get(name='Guest Student')
        # Setting the session variable
        request.session['stu_idnt'] = str(student.stu_idnt)
        return redirect('myCourses')
    except:
        return redirect('std_login')


def guestFaculty(request):
    # Clearing the session data
    request.session.flush()
    try:
        # Retrieving the guest faculty object
        faculty = Faculty.objects.get(name='Guest Faculty')
        # Setting the session variable
        request.session['faculty_id'] = str(faculty.faculty_id)
        return redirect('facultyCourses')
    except:
        return redirect('std_login')
